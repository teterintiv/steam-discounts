import assert from 'node:assert/strict';
import worker from './dist/server/index.js';
Object.defineProperty(globalThis,'caches',{get(){throw new Error('Platform cache must not be used');}});
for(const [region,currency] of [['kz','KZT'],['ru','RUB'],['ua','UAH'],['by','USD'],['uz','USD']]){
 const response=await worker.fetch(new Request('https://test.local/api/sales?region='+region));
 const data=await response.json();
 assert.equal(response.status,200);
 assert.equal(data.currency,currency);
 assert.equal(data.region,region.toUpperCase());
 assert.equal(data.stale,false);
 assert.ok(data.games.length>=90);
 assert.equal(new Set(data.games.map(g=>g.id)).size,data.games.length);
 assert.ok(data.games.every(g=>g.price>0&&g.price<g.original));
 console.log(region,data.games.length,currency,'fresh');
}
assert.equal((await worker.fetch(new Request('https://test.local/api/sales?region=invalid'))).status,400);
assert.equal((await worker.fetch(new Request('https://test.local/missing'))).status,404);
const originalFetch=globalThis.fetch;
globalThis.fetch=async()=>{throw new Error('Simulated network failure');};
const fallback=await(await worker.fetch(new Request('https://test.local/api/sales?region=am'))).json();
assert.equal(fallback.stale,true);
assert.equal(fallback.region,'AM');
globalThis.fetch=originalFetch;
console.log('Region validation and offline fallback passed');

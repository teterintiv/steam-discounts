import fs from 'node:fs';
const regions=JSON.parse(fs.readFileSync('public/regions.json','utf8').replace(/^\uFEFF/,''));
const source=fs.readFileSync('worker.js','utf8');
const {freshData}=await import('data:text/javascript;base64,'+Buffer.from('const regions='+JSON.stringify(regions)+';\n'+source).toString('base64'));
const snapshots={};let cursor=0;
await Promise.all(Array.from({length:3},async()=>{while(cursor<regions.length){const r=regions[cursor++];try{snapshots[r.code]=await freshData(r.code);console.log(r.code,snapshots[r.code].games.length,snapshots[r.code].currency, snapshots[r.code].rate);}catch(error){console.error(r.code,error.message);process.exitCode=1;}}}));
fs.writeFileSync('public/snapshots.json',JSON.stringify(snapshots));

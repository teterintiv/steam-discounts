@echo off
cd /d "%~dp0"
if exist "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" (
    "%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" preview.mjs
    goto end
)
where node >nul 2>nul
if %errorlevel% equ 0 (
    node preview.mjs
    goto end
)
echo Install Node.js 22 or newer to run the project locally.
:end
pause

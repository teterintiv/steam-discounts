import fs from 'node:fs';
const assets={};
for(const [file,type] of [['index.html','text/html; charset=utf-8'],['style.css','text/css; charset=utf-8'],['app.js','text/javascript; charset=utf-8'],['regions.json','application/json; charset=utf-8'],['snapshots.json','application/json; charset=utf-8']])assets['/'+file]={type,body:fs.readFileSync('public/'+file,'utf8').replace(/^\uFEFF/,'')};
const code=`const ASSETS=${JSON.stringify(assets)};\nconst SNAPSHOTS=${assets['/snapshots.json'].body};\nconst regions=${assets['/regions.json'].body};\n`+fs.readFileSync('worker.js','utf8');
fs.mkdirSync('dist/server',{recursive:true});fs.writeFileSync('dist/server/index.js',code);console.log('Built for '+Object.keys(JSON.parse(assets['/snapshots.json'].body)).length+' countries');

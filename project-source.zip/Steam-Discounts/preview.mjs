import http from 'node:http';
import worker from './dist/server/index.js';
const port=Number(process.env.PORT||8092);
http.createServer(async(req,res)=>{try{const response=await worker.fetch(new Request(`http://127.0.0.1:${port}${req.url}`));res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));}catch{res.writeHead(500);res.end('Server error');}}).listen(port,'127.0.0.1',()=>console.log(`http://127.0.0.1:${port}`));
